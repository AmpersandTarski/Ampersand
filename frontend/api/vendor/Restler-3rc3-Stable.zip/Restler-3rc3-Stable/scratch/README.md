The scratch pad, because great ideas wont get in our way.
