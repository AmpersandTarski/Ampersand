<?php
/**
 * Dummy class, used only for creating swagger spec model (json schema)
 * look at the generated resources json to understand
 */
class Author
{
    public $name='Name';
    public $email='name@domain.com';
}
