<?php
/**
 * All methods in this class are protected
 * @access protected
 */
class Secured {
	function index() {
		return 'protected class';
	}
}